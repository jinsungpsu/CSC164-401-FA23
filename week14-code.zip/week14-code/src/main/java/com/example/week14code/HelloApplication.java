package com.example.week14code;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class HelloApplication extends Application {

    public static Car selectedCar;
    public static Car[] garageItems = new Car[2];


    @Override
    public void start(Stage stage) throws IOException {
        Car car = new Car("Toyota", "Camry", 100);
        Car car2 = new Car("Honda", "Civic SI", 500);

        garageItems[0] = car;
        garageItems[1] = car2;

        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("garage-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 800, 600);
        stage.setTitle("<My Garage App>!");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}