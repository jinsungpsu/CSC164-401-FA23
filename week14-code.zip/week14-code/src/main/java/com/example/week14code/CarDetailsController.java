package com.example.week14code;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.IOException;

public class CarDetailsController {

    @FXML
    private Text carDetailsText;

    void goBackToGarageHandleCloseWindow(ActionEvent event) {
        Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
        stage.close();
    }

    @FXML
    void goBackToGarageHandler(ActionEvent event){
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("garage-view.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 800, 600);
            Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
            stage.setTitle("<My Garage App>!");
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            System.out.println("Something bad happened - probably with the fxml file...");
            throw new RuntimeException(e);
        }
    }

    public void initialize() {
        carDetailsText.setText(HelloApplication.selectedCar.toString());
    }

}
