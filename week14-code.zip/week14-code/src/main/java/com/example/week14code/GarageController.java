package com.example.week14code;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.stage.Stage;

import java.io.IOException;

public class GarageController {

    @FXML
    private Button addToCartButton;

    @FXML
    private ListView<Car> garageListView;

    @FXML
    private Button viewDetailsButton;

    @FXML
    void addToCartHandler(ActionEvent event) {

    }

    @FXML
    void showHondaHandler(ActionEvent event) {
        showCarsByBrand("Honda");
    }

    @FXML
    void showToyotaHandler(ActionEvent event) {
        showCarsByBrand("Toyota");
    }

    void showCarsByBrand(String brand) {
        garageListView.getItems().clear();

        for (int i = 0; i < HelloApplication.garageItems.length; i++) {
            if (HelloApplication.garageItems[i].getMake().equals(brand)) {
                garageListView.getItems().add(HelloApplication.garageItems[i]);
            }
        }
    }

    @FXML
    void viewDetailsHandler(ActionEvent event) {
        HelloApplication.selectedCar = garageListView.getSelectionModel().getSelectedItem();
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("car-details-view.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 800, 600);
            Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
            stage.setTitle("<My Garage App>!");
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            System.out.println("Something bad happened - probably with the fxml file...");
            throw new RuntimeException(e);
        }

    }
    void viewDetailsHandlerNewStage(ActionEvent event) {
        HelloApplication.selectedCar = garageListView.getSelectionModel().getSelectedItem();
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("car-details-view.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 800, 600);
            Stage stage = new Stage();
            stage.setTitle("<My Garage App>!");
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            System.out.println("Something bad happened - probably with the fxml file...");
            throw new RuntimeException(e);
        }

    }

    public void initialize() {

        for (int i = 0; i < HelloApplication.garageItems.length; i++) {
            garageListView.getItems().add(HelloApplication.garageItems[i]);
        }

    }

}
