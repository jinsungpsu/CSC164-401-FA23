package com.example.week14code;

public class Cup {
    private int amount;

    @Override
    public String toString() {
        return "this is a cup that has " + amount + " stuff in it.";
    }
}

class App {
    public static void main(String[] args) {
        Cup cup = new Cup();
        System.out.println(cup);

    }
}
