module com.example.week14code {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.week14code to javafx.fxml;
    exports com.example.week14code;
}